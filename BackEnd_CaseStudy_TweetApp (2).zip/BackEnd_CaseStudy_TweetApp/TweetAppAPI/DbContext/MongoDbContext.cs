﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetAppAPI.Models;

namespace TweetAppAPI.DbContext
{
    public class MongoDbContext : IMongoDbContext
    {
        private readonly IMongoDatabase _database;
        public MongoDbContext(IMongoClient mongoClient)
        {
            _database = mongoClient.GetDatabase("TweetAppDB");
        }

        //Retriving user details from UserData collection
        public IMongoCollection<User> GetUserDetails()
        {
            return _database.GetCollection<User>("UserData");
        }
        //Retriving tweet details from TweetData collection
        public IMongoCollection<Tweet> GetTweetDetails()
        {
            return _database.GetCollection<Tweet>("TweetData");
        }
    }
}
